# Discord Bot

## Overview

This is a Discord bot built with Discord.js v14 that supports both slash commands and traditional prefix commands. The bot features a modular architecture with separate command and event handlers, comprehensive logging, and automated command deployment. It includes basic utility commands like ping and hello, demonstrating both interaction types for maximum compatibility.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Command System Architecture
The bot implements a dual command system to support both modern slash commands and legacy prefix commands:

**Slash Commands**: Modern Discord application commands stored in the `/commands` directory, each exporting a `data` property (SlashCommandBuilder) and an `execute` function. Commands are automatically loaded and registered via the deployment script.

**Prefix Commands**: Traditional message-based commands handled through the messageCreate event with a `!` prefix for backwards compatibility.

**Rationale**: This hybrid approach ensures compatibility with users preferring either command style while leveraging Discord's modern slash command features.

### Event-Driven Architecture
Events are modularized in the `/events` directory with each file handling specific Discord.js events:
- `ready.js`: Bot initialization and status setup
- `interactionCreate.js`: Slash command interaction handling
- `messageCreate.js`: Traditional prefix command processing

**Benefits**: Clean separation of concerns, easy event management, and simplified debugging.

### Logging System
Custom logger utility (`/utils/logger.js`) provides:
- Console output with color-coded log levels
- File-based logging with daily rotation
- Structured timestamp formatting
- Error tracking and command usage monitoring

**Design Choice**: File-based logging ensures persistence of bot activity and errors for debugging, while console output provides real-time monitoring during development.

### Modular File Structure
```
/commands/          # Slash command definitions
/events/            # Discord event handlers
/utils/             # Utility functions (logger)
/logs/              # Auto-generated log files
deploy-commands.js  # Command registration script
index.js           # Main bot entry point
```

**Rationale**: Modular structure enables easy feature addition, maintainable codebase, and clear separation between bot logic, commands, and utilities.

### Error Handling Strategy
Comprehensive error handling includes:
- Try-catch blocks around command execution
- Graceful error responses to users
- Detailed error logging for debugging
- Fallback responses for unknown commands

## External Dependencies

### Discord.js Framework
- **Version**: 14.22.1
- **Purpose**: Core Discord API interaction library
- **Features Used**: Gateway intents, slash commands, event handling, REST API

### Node.js Built-ins
- **fs**: File system operations for command/event loading and logging
- **path**: Cross-platform file path handling
- **dotenv**: Environment variable management for sensitive tokens

### Environment Variables Required
- `DISCORD_TOKEN`: Bot authentication token
- `DISCORD_CLIENT_ID`: Application client ID for command deployment
- `DISCORD_GUILD_ID`: Optional guild ID for testing commands locally

### Discord API Integration
- **Slash Commands**: Registered via Discord's REST API
- **Gateway Events**: Real-time event handling through WebSocket connection
- **Permissions**: Configurable bot permissions through OAuth2 invite links
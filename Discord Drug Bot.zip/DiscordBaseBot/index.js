const { Client, GatewayIntentBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, SlashCommandBuilder, REST, Routes, Events, PermissionFlagsBits } = require('discord.js');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus } = require('@discordjs/voice');
require('dotenv').config();
const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildVoiceStates
  ]
});

// Guild-specific configuration storage
const GUILD_CONFIGS = new Map();
const CONFIG_FILE = path.join(__dirname, 'guild_configs.json');

// Cooldown storage for denied users (userId -> timestamp)
const DENIED_COOLDOWNS = new Map();

// Load saved configurations
function loadConfigs() {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const data = fs.readFileSync(CONFIG_FILE, 'utf8');
      const configs = JSON.parse(data);
      for (const [guildId, config] of Object.entries(configs)) {
        GUILD_CONFIGS.set(guildId, config);
      }
      console.log(`Loaded configurations for ${GUILD_CONFIGS.size} guilds`);
    }
  } catch (error) {
    console.error('Error loading configurations:', error);
  }
}

// Save configurations to file
function saveConfigs() {
  try {
    const configs = Object.fromEntries(GUILD_CONFIGS);
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(configs, null, 2));
  } catch (error) {
    console.error('Error saving configurations:', error);
  }
}

// Get configuration for a specific guild
function getGuildConfig(guildId) {
  if (!GUILD_CONFIGS.has(guildId)) {
    // Default configuration for new guilds
    GUILD_CONFIGS.set(guildId, {
      GUILD_ID: guildId,
      CHANNEL_ID: '',
      OWNER_ID: '',
      DRUG_CHANNEL_ID: '',
      AUTO_ALLOW: false
    });
    saveConfigs();
  }
  return GUILD_CONFIGS.get(guildId);
}

// Update configuration for a specific guild
function updateGuildConfig(guildId, updates) {
  const config = getGuildConfig(guildId);
  Object.assign(config, updates);
  GUILD_CONFIGS.set(guildId, config);
  saveConfigs();
}

// Express server for keep-alive
app.get('/', (req, res) => {
  res.send(`Drug Detection Voice Bot is running! Serving ${GUILD_CONFIGS.size} guilds.`);
});

app.listen(3000, () => {
  console.log('Express server running on port 3000');
});

// Slash commands setup
const commands = [
  new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Setup the drug detection system for this server')
    .addChannelOption(option =>
      option.setName('drug_channel')
        .setDescription('The channel where users will type "drug"')
        .setRequired(true)
    )
    .addChannelOption(option =>
      option.setName('notification_channel')
        .setDescription('The channel where notifications will be sent')
        .setRequired(true)
    )
    .addUserOption(option =>
      option.setName('owner')
        .setDescription('The server owner who will receive notifications')
        .setRequired(true)
    )
    .addBooleanOption(option =>
      option.setName('auto_allow')
        .setDescription('Auto-allow users to join voice channel without approval (default: false)')
        .setRequired(false)
    ),
  new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show help guide for the drug detection system'),
  new SlashCommandBuilder()
    .setName('config')
    .setDescription('Show current configuration for this server')
].map(command => command.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

// Bot events
client.once(Events.ClientReady, async () => {
  console.log(`Logged in as ${client.user.tag}!`);

  // Load existing configurations
  loadConfigs();

  try {
    console.log('Started refreshing application (/) commands.');
    await rest.put(
      Routes.applicationCommands(client.user.id),
      { body: commands },
    );
    console.log('Successfully reloaded application (/) commands.');
  } catch (error) {
    console.error(error);
  }
});

// Message detection for "drug"
client.on(Events.MessageCreate, async message => {
  // Ignore bot messages
  if (message.author.bot) return;

  // Ignore DMs
  if (!message.guild) return;

  const guildConfig = getGuildConfig(message.guild.id);

  // Check if message is in the designated drug channel
  if (message.channel.id !== guildConfig.DRUG_CHANNEL_ID) return;

  // Check if message contains "drug" (case insensitive)
  if (!message.content.toLowerCase().includes('drug')) return;

  // Check if user is on cooldown from being denied
  const cooldownKey = `${message.author.id}_${message.guild.id}`;
  const cooldownTime = DENIED_COOLDOWNS.get(cooldownKey);
  if (cooldownTime && Date.now() < cooldownTime) {
    const timeLeft = Math.ceil((cooldownTime - Date.now()) / 1000 / 60);
    try {
      await message.author.send(`❌ You were recently denied access. Please wait ${timeLeft} more minutes before trying again.`);
    } catch (error) {
      console.log(`Could not send DM to ${message.author.tag}`);
    }
    // During cooldown period, bot will NOT join voice channel or announce anything
    return;
  }

  // If cooldown has expired, remove it from storage
  if (cooldownTime && Date.now() >= cooldownTime) {
    DENIED_COOLDOWNS.delete(cooldownKey);
    console.log(`[${message.guild.name}] Cooldown expired for user ${message.author.tag}`);
  }

  // Check if owner is set
  if (!guildConfig.OWNER_ID) {
    await message.reply('❌ Server owner not configured. Please use `/setup` command first.');
    return;
  }

  // Check if user is in a voice channel
  const guild = message.guild;
  const userMember = await guild.members.fetch(message.author.id);

  if (!userMember.voice.channel) {
    await message.reply('❌ You must be in a voice channel to make this request. Please join a voice channel first and try again.');
    return;
  }

  // Find the owner
  const owner = await client.users.fetch(guildConfig.OWNER_ID);
  if (!owner) {
    await message.reply('❌ Server owner not found.');
    return;
  }

  // Get owner's voice channel
  const ownerMember = await guild.members.fetch(guildConfig.OWNER_ID);
  const ownerVoiceChannel = ownerMember.voice.channel;

  if (!ownerVoiceChannel) {
    // Owner is not in a voice channel
    await message.reply('❌ Owner is not currently in a voice channel.');
    return;
  }

  // Create embed for join request
  const requestEmbed = new EmbedBuilder()
    .setColor(0xFF6B6B)
    .setTitle('🔊 Voice Channel Join Request')
    .setDescription(`${message.author.tag} wants to join your voice channel.`)
    .addFields(
      { name: 'Server', value: `${guild.name}`, inline: true },
      { name: 'User', value: `<@${message.author.id}>`, inline: true },
      { name: 'User\'s Current Voice Channel', value: `${userMember.voice.channel.name}`, inline: true },
      { name: 'Owner\'s Voice Channel', value: `${ownerVoiceChannel.name}`, inline: true },
      { name: 'Request Time', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
      { name: 'Triggered Message', value: `"${message.content}"`, inline: false }
    )
    .setThumbnail(message.author.displayAvatarURL())
    .setTimestamp();

  // Create action buttons
  const actionRow = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId(`accept_voice_${message.author.id}_${ownerVoiceChannel.id}_${guild.id}`)
        .setLabel('Accept')
        .setStyle(ButtonStyle.Success)
        .setEmoji('✅'),
      new ButtonBuilder()
        .setCustomId(`deny_voice_${message.author.id}_${guild.id}`)
        .setLabel('Deny')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('❌')
    );

  // Bot joins owner's voice channel and announces
  try {
    // Join the owner's voice channel
    const connection = joinVoiceChannel({
      channelId: ownerVoiceChannel.id,
      guildId: guild.id,
      adapterCreator: guild.voiceAdapterCreator,
    });

    console.log(`[${guild.name}] Bot joined voice channel: ${ownerVoiceChannel.name}`);

    // Announce in voice channel with text-to-speech
    const player = createAudioPlayer();
    connection.subscribe(player);

    try {
      // Create attention sound notification
      console.log(`[${guild.name}] Bot announcing join in voice channel`);
      
      const fs = require('fs');
      const path = require('path');
      const ffmpeg = require('ffmpeg-static');
      const { spawn } = require('child_process');
      
      console.log(`[${guild.name}] Creating notification sound...`);
      
      // Create notification audio file
      const notificationPath = path.join(__dirname, 'notification.wav');
      
      // Generate attention sound with better error handling
      await new Promise((resolve, reject) => {
        console.log(`[${guild.name}] Creating attention notification sound...`);
        
        // Create a simpler, faster notification sound
        const ffmpegProcess = spawn(ffmpeg, [
          '-f', 'lavfi',
          '-i', 'sine=frequency=880:duration=0.5',
          '-ar', '44100',
          '-ac', '1',
          '-af', 'volume=0.6',
          '-f', 'wav',
          '-t', '0.5',
          '-y',
          notificationPath
        ]);
        
        ffmpegProcess.on('close', (code) => {
          console.log(`[${guild.name}] Notification sound created with code ${code}`);
          resolve(); // Always resolve to continue
        });
        
        ffmpegProcess.on('error', (error) => {
          console.log(`[${guild.name}] Notification sound creation error:`, error.message);
          resolve(); // Resolve to continue without audio
        });
        
        // Reduced timeout
        setTimeout(() => {
          console.log(`[${guild.name}] Notification sound creation timeout - continuing without sound`);
          ffmpegProcess.kill('SIGKILL');
          resolve();
        }, 3000);
      });

      // Create TTS announcement using Google TTS
      const announcementText = `Attention! ${message.author.username} wants to join your voice channel.`;
      const ttsPath = path.join(__dirname, 'tts_announcement.wav');
      
      try {
        // Use Google TTS for better voice quality
        const gTTS = require('node-gtts')('en');
        
        await new Promise((resolve, reject) => {
          console.log(`[${guild.name}] Creating TTS announcement with Google TTS...`);
          
          gTTS.save(ttsPath, announcementText, (err) => {
            if (err) {
              console.log(`[${guild.name}] Google TTS failed, using fallback beep sound`);
              // Fallback to simple beep sound
              const beepProcess = spawn(ffmpeg, [
                '-f', 'lavfi',
                '-i', 'sine=frequency=880:duration=0.3,sine=frequency=1108:duration=0.3,sine=frequency=880:duration=0.3',
                '-ar', '48000',
                '-ac', '2',
                '-af', 'volume=0.6',
                '-f', 'wav',
                '-y',
                ttsPath
              ]);
              
              beepProcess.on('close', () => {
                console.log(`[${guild.name}] Fallback beep sound created`);
                resolve();
              });
              
              beepProcess.on('error', () => resolve());
              setTimeout(() => resolve(), 3000);
            } else {
              console.log(`[${guild.name}] TTS announcement created successfully with Google TTS`);
              resolve();
            }
          });
        });
        
        // Play the TTS announcement
        let audioPlayed = false;
        
        if (fs.existsSync(ttsPath)) {
          try {
            const ttsResource = createAudioResource(ttsPath, {
              inputType: require('@discordjs/voice').StreamType.Arbitrary,
            });
            
            player.play(ttsResource);
            console.log(`[${guild.name}] Playing TTS announcement: "${announcementText}"`);
            audioPlayed = true;

            // Clean up after playing
            player.once(AudioPlayerStatus.Idle, () => {
              console.log(`[${guild.name}] Audio announcement finished`);
              setTimeout(() => {
                try {
                  if (fs.existsSync(ttsPath)) fs.unlinkSync(ttsPath);
                  if (fs.existsSync(notificationPath)) fs.unlinkSync(notificationPath);
                  console.log(`[${guild.name}] Cleaned up audio files`);
                } catch (err) {
                  console.log(`[${guild.name}] Could not clean up files:`, err.message);
                }
              }, 1000);
            });

            player.on('error', (error) => {
              console.error(`[${guild.name}] Audio player error:`, error);
            });
            
          } catch (error) {
            console.error(`[${guild.name}] Error creating TTS audio resource:`, error);
          }
        }
        
        // If TTS failed, try notification sound as fallback
        if (!audioPlayed && fs.existsSync(notificationPath)) {
          try {
            const resource = createAudioResource(notificationPath, {
              inputType: require('@discordjs/voice').StreamType.Arbitrary,
            });
            
            player.play(resource);
            console.log(`[${guild.name}] Playing fallback notification sound`);
            audioPlayed = true;
          } catch (error) {
            console.error(`[${guild.name}] Error playing fallback sound:`, error);
          }
        }
        
        // If no audio could be played, just announce in text
        if (!audioPlayed) {
          console.log(`[${guild.name}] No audio played - voice announcement failed`);
        }
        
        // Clean up notification file after use
        player.on(AudioPlayerStatus.Idle, () => {
          setTimeout(() => {
            try {
              if (fs.existsSync(notificationPath)) {
                fs.unlinkSync(notificationPath);
                console.log(`[${guild.name}] Cleaned up notification file`);
              }
            } catch (err) {
              console.log(`[${guild.name}] Could not clean up notification file:`, err);
            }
          }, 1000);
        });
        
      } catch (error) {
        console.error(`[${guild.name}] Error with audio announcement:`, error);
        // Continue without audio
      }

    } catch (audioError) {
      console.error(`[${guild.name}] Error with TTS announcement:`, audioError);
      // Continue without audio if there's an error
    }

    // Send notification to text channel
    const notificationChannel = client.channels.cache.get(guildConfig.CHANNEL_ID);
    if (notificationChannel) {
      await notificationChannel.send({
        content: `🔊 **ATTENTION:** Bot has joined voice channel **${ownerVoiceChannel.name}**!\n<@${guildConfig.OWNER_ID}> **${message.author.tag}** wants to join your voice channel and is requesting access!`,
        embeds: [requestEmbed],
        components: [actionRow]
      });
    } else {
      // Send DM to owner if channel not found
      await owner.send({
        content: `🔊 **URGENT:** Bot joined your voice channel **${ownerVoiceChannel.name}** in **${guild.name}**!\nSomeone is requesting to join!`,
        embeds: [requestEmbed],
        components: [actionRow]
      });
    }

    // Leave voice channel after 30 seconds (increased for better notification)
    setTimeout(() => {
      try {
        connection.destroy();
        console.log(`[${guild.name}] Bot left voice channel: ${ownerVoiceChannel.name}`);
      } catch (error) {
        console.error('Error leaving voice channel:', error);
      }
    }, 30000);

    // Confirm to the user
    // Check if auto-allow is enabled
    if (guildConfig.AUTO_ALLOW) {
      // Auto-allow: directly move user to owner's voice channel
      try {
        if (userMember.voice.channel) {
          await userMember.voice.setChannel(ownerVoiceChannel);
          await message.reply(`✅ You have been automatically moved to **${ownerVoiceChannel.name}**!`);
        } else {
          // User not in voice channel, create invite
          const invite = await ownerVoiceChannel.createInvite({
            maxAge: 300, // 5 minutes
            maxUses: 1,
            unique: true
          });

          const inviteEmbed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle('✅ Auto-Approved Voice Channel Access!')
            .setDescription(`You have been automatically approved to join **${ownerVoiceChannel.name}** in **${guild.name}**`)
            .addFields(
              { name: 'Join Link', value: `[Click here to join](${invite.url})` },
              { name: 'Expires', value: '<t:' + Math.floor((Date.now() + 300000) / 1000) + ':R>' }
            )
            .setTimestamp();

          await message.author.send({ embeds: [inviteEmbed] });
          await message.reply('✅ You have been auto-approved! Check your DMs for the voice channel invite.');
        }

        // Notify in notification channel
        const notificationChannel = client.channels.cache.get(guildConfig.CHANNEL_ID);
        if (notificationChannel) {
          const autoNotifyEmbed = new EmbedBuilder()
            .setColor(0x00FF00)
            .setTitle('🔊 Auto-Approved Voice Channel Access')
            .setDescription(`${message.author.tag} was automatically moved to voice channel.`)
            .addFields(
              { name: 'User', value: `<@${message.author.id}>`, inline: true },
              { name: 'Voice Channel', value: `${ownerVoiceChannel.name}`, inline: true },
              { name: 'Auto-Allow Status', value: '✅ ON', inline: true }
            )
            .setTimestamp();

          await notificationChannel.send({ embeds: [autoNotifyEmbed] });
        }

        return; // Skip the manual approval process
      } catch (error) {
        console.error('Error with auto-allow:', error);
        await message.reply('❌ Auto-allow failed. Please try again.');
        return;
      }
    }

    await message.reply('✅ Bot has joined the voice channel and announced your request!');
  } catch (error) {
    console.error('Error with voice channel operation:', error);
    await message.reply('❌ Failed to join voice channel. Please try again later.');
  }
});

// Slash command handler
client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const guildConfig = getGuildConfig(interaction.guild.id);

  if (interaction.commandName === 'setup') {
    if (!interaction.memberPermissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ 
        content: '❌ You need administrator permissions to use this command.', 
        ephemeral: true 
      });
    }

    const drugChannel = interaction.options.getChannel('drug_channel');
    const notificationChannel = interaction.options.getChannel('notification_channel');
    const owner = interaction.options.getUser('owner');
    const autoAllow = interaction.options.getBoolean('auto_allow') || false;

    updateGuildConfig(interaction.guild.id, {
      DRUG_CHANNEL_ID: drugChannel.id,
      CHANNEL_ID: notificationChannel.id,
      OWNER_ID: owner.id,
      AUTO_ALLOW: autoAllow
    });

    const setupEmbed = new EmbedBuilder()
      .setColor(0x00FF00)
      .setTitle('✅ Drug Detection System Setup Complete!')
      .setDescription(`The system is now configured for **${interaction.guild.name}**.`)
      .addFields(
        { name: 'Drug Detection Channel', value: `${drugChannel}`, inline: true },
        { name: 'Notification Channel', value: `${notificationChannel}`, inline: true },
        { name: 'Server Owner', value: `${owner}`, inline: true },
        { name: 'Auto Allow', value: `${autoAllow ? '✅ ON' : '❌ OFF'}`, inline: true },
        { name: 'How it works', value: autoAllow ? 'When someone types "drug" in the detection channel, they will be automatically moved to the owner\'s voice channel without approval.' : 'When someone types "drug" in the detection channel, the owner will receive a notification with options to accept or deny voice channel access.' }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [setupEmbed], ephemeral: true });
  }

  if (interaction.commandName === 'config') {
    const drugChannel = guildConfig.DRUG_CHANNEL_ID ? `<#${guildConfig.DRUG_CHANNEL_ID}>` : 'Not set';
    const notificationChannel = guildConfig.CHANNEL_ID ? `<#${guildConfig.CHANNEL_ID}>` : 'Not set';
    const owner = guildConfig.OWNER_ID ? `<@${guildConfig.OWNER_ID}>` : 'Not set';
    const autoAllow = guildConfig.AUTO_ALLOW ? '✅ ON' : '❌ OFF';

    const configEmbed = new EmbedBuilder()
      .setColor(0x3498DB)
      .setTitle(`⚙️ Configuration for ${interaction.guild.name}`)
      .addFields(
        { name: 'Drug Detection Channel', value: drugChannel, inline: true },
        { name: 'Notification Channel', value: notificationChannel, inline: true },
        { name: 'Server Owner', value: owner, inline: true },
        { name: 'Auto Allow', value: autoAllow, inline: true }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [configEmbed], ephemeral: true });
  }

  if (interaction.commandName === 'help') {
    const helpEmbed = new EmbedBuilder()
      .setColor(0x3498DB)
      .setTitle('🔊 Drug Detection Voice Bot Help')
      .setDescription('This bot detects when users type "drug" and allows owner to invite them to voice channels.')
      .addFields(
        { name: 'How it works', value: '1. User types "drug" in designated channel\n2. Owner gets notification in voice channel\n3. Owner can accept or deny the request\n4. Accepted users get moved to owner\'s voice channel\n5. Denied users receive a DM notification' },
        { name: 'Setup', value: 'Use `/setup` command to configure channels (Admin only)' },
        { name: 'Configuration', value: 'Use `/config` command to see current settings' },
        { name: 'Requirements', value: 'Owner must be in a voice channel to receive requests' },
        { name: 'Multi-Server Support', value: 'Each server has its own separate configuration' }
      )
      .setFooter({ text: 'Bot created for voice channel management' });

    await interaction.reply({ embeds: [helpEmbed], ephemeral: true });
  }
});

// Button interaction handler
client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isButton()) return;

  // Accept voice channel request
  if (interaction.customId.startsWith('accept_voice_')) {
    const parts = interaction.customId.split('_');
    const userId = parts[2];
    const voiceChannelId = parts[3];
    const guildId = parts[4];

    const guildConfig = getGuildConfig(guildId);

    if (interaction.user.id !== guildConfig.OWNER_ID) {
      return interaction.reply({ 
        content: '❌ Only the server owner can accept voice requests.', 
        ephemeral: true 
      });
    }

    try {
      const guild = client.guilds.cache.get(guildId);
      if (!guild) {
        return interaction.reply({ 
          content: '❌ Guild not found.', 
          ephemeral: true 
        });
      }

      const member = await guild.members.fetch(userId);
      const voiceChannel = guild.channels.cache.get(voiceChannelId);

      if (!member) {
        return interaction.reply({ 
          content: '❌ User not found.', 
          ephemeral: true 
        });
      }

      if (!voiceChannel) {
        return interaction.reply({ 
          content: '❌ Voice channel not found.', 
          ephemeral: true 
        });
      }

      // Move user to voice channel
      if (member.voice.channel) {
        await member.voice.setChannel(voiceChannel);
      } else {
        // User is not in any voice channel, send them an invite
        const invite = await voiceChannel.createInvite({
          maxAge: 300, // 5 minutes
          maxUses: 1,
          unique: true
        });

        const inviteEmbed = new EmbedBuilder()
          .setColor(0x00FF00)
          .setTitle('✅ Voice Channel Invitation Accepted!')
          .setDescription(`You have been invited to join the voice channel: **${voiceChannel.name}** in **${guild.name}**`)
          .addFields(
            { name: 'Join Link', value: `[Click here to join](${invite.url})` },
            { name: 'Expires', value: '<t:' + Math.floor((Date.now() + 300000) / 1000) + ':R>' }
          )
          .setTimestamp();

        await member.send({ embeds: [inviteEmbed] });
      }

      await interaction.reply({ 
        content: `✅ ${member.user.tag} has been invited to join the voice channel.`, 
        ephemeral: true 
      });

      // Update the original message
      const updatedEmbed = EmbedBuilder.from(interaction.message.embeds[0])
        .setColor(0x00FF00)
        .setTitle('✅ Voice Request Accepted');

      await interaction.message.edit({
        content: `✅ Accepted by ${interaction.user.tag}`,
        embeds: [updatedEmbed],
        components: []
      });

    } catch (error) {
      console.error('Error moving user to voice channel:', error);
      await interaction.reply({ 
        content: '❌ Failed to move user to voice channel. Make sure the bot has proper permissions.', 
        ephemeral: true 
      });
    }
  }

  // Deny voice channel request
  if (interaction.customId.startsWith('deny_voice_')) {
    const parts = interaction.customId.split('_');
    const userId = parts[2];
    const guildId = parts[3];

    const guildConfig = getGuildConfig(guildId);

    if (interaction.user.id !== guildConfig.OWNER_ID) {
      return interaction.reply({ 
        content: '❌ Only the server owner can deny voice requests.', 
        ephemeral: true 
      });
    }

    try {
      const user = await client.users.fetch(userId);
      const guild = client.guilds.cache.get(guildId);

      // Set 10-minute cooldown for this user in this guild
      const cooldownKey = `${userId}_${guildId}`;
      const cooldownTime = Date.now() + (10 * 60 * 1000); // 10 minutes from now
      DENIED_COOLDOWNS.set(cooldownKey, cooldownTime);

      if (user) {
        const denyEmbed = new EmbedBuilder()
          .setColor(0xFF0000)
          .setTitle('❌ Voice Channel Request Denied')
          .setDescription(`Your request to join the voice channel in **${guild?.name || 'Unknown Server'}** has been denied by the server owner.\n\n⏰ You must wait **10 minutes** before making another request.`)
          .setTimestamp();

        await user.send({ embeds: [denyEmbed] });
      }

      await interaction.reply({ 
        content: `❌ Voice request from ${user?.tag || 'unknown user'} has been denied. They are now on a 10-minute cooldown.`, 
        ephemeral: true 
      });

      // Update the original message
      const updatedEmbed = EmbedBuilder.from(interaction.message.embeds[0])
        .setColor(0xFF0000)
        .setTitle('❌ Voice Request Denied');

      await interaction.message.edit({
        content: `❌ Denied by ${interaction.user.tag}`,
        embeds: [updatedEmbed],
        components: []
      });

    } catch (error) {
      console.error('Error sending deny DM:', error);
      await interaction.reply({ 
        content: '❌ Request denied, but failed to send DM to user.', 
        ephemeral: true 
      });
    }
  }
});

// Error handling
client.on('error', console.error);
process.on('unhandledRejection', console.error);

// Start the bot
client.login(process.env.DISCORD_TOKEN);
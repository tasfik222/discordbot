const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();
const logger = require('./utils/logger');

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

// Load all commands
for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    
    if ('data' in command && 'execute' in command) {
        commands.push(command.data.toJSON());
        logger.info(`Loaded command for deployment: ${command.data.name}`);
    } else {
        logger.warn(`The command at ${filePath} is missing a required "data" or "execute" property.`);
    }
}

// Deploy commands
async function deployCommands() {
    const token = process.env.DISCORD_TOKEN;
    const clientId = process.env.DISCORD_CLIENT_ID;
    const guildId = process.env.DISCORD_GUILD_ID; // Optional: for guild-specific commands
    
    if (!token) {
        logger.error('DISCORD_TOKEN environment variable is not set!');
        process.exit(1);
    }
    
    if (!clientId) {
        logger.error('DISCORD_CLIENT_ID environment variable is not set!');
        process.exit(1);
    }
    
    const rest = new REST().setToken(token);
    
    try {
        logger.info(`Started refreshing ${commands.length} application (/) commands.`);
        
        let data;
        
        if (guildId) {
            // Deploy to specific guild (faster for testing)
            data = await rest.put(
                Routes.applicationGuildCommands(clientId, guildId),
                { body: commands }
            );
            logger.info(`Successfully reloaded ${data.length} guild application (/) commands for guild ${guildId}.`);
        } else {
            // Deploy globally (takes up to 1 hour to propagate)
            data = await rest.put(
                Routes.applicationCommands(clientId),
                { body: commands }
            );
            logger.info(`Successfully reloaded ${data.length} global application (/) commands.`);
        }
        
    } catch (error) {
        logger.error('Error deploying commands:', error);
    }
}

// Run deployment if this file is executed directly
if (require.main === module) {
    deployCommands();
}

module.exports = { deployCommands };

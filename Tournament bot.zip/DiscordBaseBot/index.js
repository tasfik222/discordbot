const { Client, GatewayIntentBits, Partials, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, PermissionsBitField } = require('discord.js');
require("dotenv").config();
require('./keep_alive'); // Keep the bot alive 24/7

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ],
    partials: [Partials.Channel]
});

// Guild-specific data storage
let guildData = new Map(); // Map guild ID to guild-specific data

// Function to get or create guild data
function getGuildData(guildId) {
    if (!guildData.has(guildId)) {
        guildData.set(guildId, {
            registrationOpen: true,
            tournamentMode: null,
            registeredUsers: new Set(),
            registeredTeamNames: new Set(),
            userTeamMap: new Map()
        });
    }
    return guildData.get(guildId);
}

client.once("clientReady", async () => {
    console.log(`${client.user.tag} is online!`);
    
    // Register slash commands
    const commands = [
        {
            name: 'setup',
            description: 'Setup tournament mode and registration'
        },
        {
            name: 'setupgroup',
            description: 'Setup groups for teams',
            options: [
                {
                    name: 'groups',
                    description: 'Number of groups to create',
                    type: 4, // INTEGER
                    required: true,
                    min_value: 2,
                    max_value: 10
                },
                {
                    name: 'channel',
                    description: 'Channel to post group results',
                    type: 7, // CHANNEL
                    required: true
                }
            ]
        }
    ];

    try {
        await client.application?.commands.set(commands);
        console.log('Slash commands registered successfully!');
    } catch (error) {
        console.error('Error registering slash commands:', error);
    }
});

// 🟢 Setup Registration Panel Command
client.on("messageCreate", async (message) => {
    if (!message.content.startsWith("!setup") || !message.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

    const embed = new EmbedBuilder()
        .setTitle("🎮 Tournament Setup")
        .setDescription("Choose tournament mode:")
        .setColor("Blue");

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId("mode_solo").setLabel("Solo").setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId("mode_duo").setLabel("Duo").setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId("mode_squad").setLabel("Squad (4 Players)").setStyle(ButtonStyle.Success)
    );

    message.channel.send({ embeds: [embed], components: [row] });
});

// 🟢 Handle Slash Commands
client.on("interactionCreate", async (interaction) => {
    if (interaction.isChatInputCommand()) {
        // /setup command - shows tournament mode selection
        if (interaction.commandName === 'setup') {
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                return interaction.reply({ content: "❌ Only admins can use this command.", ephemeral: true });
            }

            const embed = new EmbedBuilder()
                .setTitle("🎮 Tournament Setup")
                .setDescription("Choose tournament mode:")
                .setColor("Blue");

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId("mode_solo").setLabel("Solo").setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId("mode_duo").setLabel("Duo").setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId("mode_squad").setLabel("Squad (4 Players)").setStyle(ButtonStyle.Success)
            );

            return interaction.reply({ embeds: [embed], components: [row] });
        }

        // /setupgroup command - creates groups for teams
        if (interaction.commandName === 'setupgroup') {
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                return interaction.reply({ content: "❌ Only admins can use this command.", ephemeral: true });
            }

            const guild = getGuildData(interaction.guild.id);
            const numGroups = interaction.options.getInteger('groups');
            const channel = interaction.options.getChannel('channel');

            if (guild.registeredTeamNames.size === 0) {
                return interaction.reply({ content: "❌ No teams are registered yet! Run tournament registration first.", ephemeral: true });
            }

            // Convert registered team names to array and shuffle
            const teams = Array.from(guild.registeredTeamNames);
            const shuffledTeams = teams.sort(() => Math.random() - 0.5);

            // Distribute teams into groups
            const groups = Array.from({ length: numGroups }, () => []);
            shuffledTeams.forEach((team, index) => {
                groups[index % numGroups].push(team);
            });

            // Create embed for group display
            const embed = new EmbedBuilder()
                .setTitle(`🎮 Tournament Groups (${teams.length} Teams)`)
                .setDescription(`Teams have been randomly divided into ${numGroups} groups:`)
                .setColor("Gold")
                .setTimestamp();

            // Add fields for each group
            groups.forEach((groupTeams, index) => {
                const groupName = `Group ${index + 1}`;
                const teamList = groupTeams.map(team => `• ${team}`).join('\n') || 'No teams';
                embed.addFields({ 
                    name: `🏆 ${groupName}`, 
                    value: teamList, 
                    inline: true 
                });
            });

            // Send to specified channel
            try {
                await channel.send({ embeds: [embed] });
                await interaction.reply({ 
                    content: `✅ Groups created successfully! Results posted in ${channel}.`, 
                    ephemeral: true 
                });
            } catch (error) {
                await interaction.reply({ 
                    content: "❌ Error posting to channel. Make sure I have permission to send messages there.", 
                    ephemeral: true 
                });
            }
        }
        return;
    }

    // 🟢 Handle Button Clicks
    if (!interaction.isButton()) return;

    // MODE SELECTION BUTTONS
    if (interaction.customId.startsWith("mode_")) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.reply({ content: "❌ Only admins can set tournament mode.", ephemeral: true });
        }

        const guild = getGuildData(interaction.guild.id);
        guild.tournamentMode = interaction.customId.replace("mode_", "");
        guild.registrationOpen = true;

        let modeText = "";
        if (guild.tournamentMode === "solo") modeText = "Solo (1 player per team)";
        else if (guild.tournamentMode === "duo") modeText = "Duo (2 players per team)";
        else if (guild.tournamentMode === "squad") modeText = "Squad (4 players per team)";

        const embed = new EmbedBuilder()
            .setTitle("🎮 Tournament Registration")
            .setDescription(`Mode: **${modeText}**\n\nClick **Register** to join the tournament.\nAdmins can **Finish** or **Start** tournament.`)
            .setColor("Green");

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId("register").setLabel("Register").setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId("finish").setLabel("Finish").setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId("start").setLabel("Start").setStyle(ButtonStyle.Primary)
        );

        await interaction.update({ embeds: [embed], components: [row] });
        return;
    }

    // REGISTER BUTTON
    if (interaction.customId === "register") {
        const guild = getGuildData(interaction.guild.id);
        
        if (!guild.tournamentMode) {
            return interaction.reply({ content: "❌ Tournament mode not set! Admin needs to run !setup first.", ephemeral: true });
        }
        if (!guild.registrationOpen) {
            return interaction.reply({ content: "❌ Registration is closed!", ephemeral: true });
        }

        // Check if user is already registered in this guild
        if (guild.registeredUsers.has(interaction.user.id)) {
            return interaction.reply({ content: "❌ You are already registered for the tournament!", ephemeral: true });
        }

        const modal = new ModalBuilder()
            .setCustomId("regModal")
            .setTitle("Tournament Registration");

        const teamName = new TextInputBuilder()
            .setCustomId("teamName")
            .setLabel("Enter Team Name")
            .setStyle(TextInputStyle.Short)
            .setRequired(true);

        const ign = new TextInputBuilder()
            .setCustomId("ign")
            .setLabel("Your IGN (In-game Name)")
            .setStyle(TextInputStyle.Short)
            .setRequired(true);

        modal.addComponents(
            new ActionRowBuilder().addComponents(teamName),
            new ActionRowBuilder().addComponents(ign)
        );

        if (guild.tournamentMode === "duo") {
            const teammate = new TextInputBuilder()
                .setCustomId("teammate")
                .setLabel("Teammate User ID")
                .setStyle(TextInputStyle.Short)
                .setRequired(true);
            modal.addComponents(new ActionRowBuilder().addComponents(teammate));
        } else if (guild.tournamentMode === "squad") {
            const teammates = new TextInputBuilder()
                .setCustomId("teammates")
                .setLabel("3 Teammates User IDs (123456789, 987654321, 555666777)")
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true);
            modal.addComponents(new ActionRowBuilder().addComponents(teammates));
        }

        await interaction.showModal(modal);
    }

    // FINISH BUTTON (Admin only)
    if (interaction.customId === "finish") {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.reply({ content: "❌ Only admins can use this.", ephemeral: true });
        }
        const guild = getGuildData(interaction.guild.id);
        guild.registrationOpen = false;
        interaction.reply("✅ Registration has been **closed**.");
    }

    // START BUTTON (Admin only)
    if (interaction.customId === "start") {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.reply({ content: "❌ Only admins can use this.", ephemeral: true });
        }

        // Create Tournament Start Category
        let tournamentCategory = await interaction.guild.channels.create({
            name: "Tournament Start",
            type: 4, // Category
        });

        // Get all registered team roles
        const guild = getGuildData(interaction.guild.id);
        let registeredRoles = [];
        for (let teamName of guild.registeredTeamNames) {
            let role = interaction.guild.roles.cache.find(r => r.name === teamName);
            if (role) registeredRoles.push(role);
        }

        // Create Tournament Chat (text channel - can send messages)
        await interaction.guild.channels.create({
            name: "tournament-chat",
            type: 0, // Text
            parent: tournamentCategory.id,
            permissionOverwrites: [
                {
                    id: interaction.guild.id,
                    deny: [PermissionsBitField.Flags.ViewChannel]
                },
                ...registeredRoles.map(role => ({
                    id: role.id,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
                }))
            ]
        });

        // Create Tournament VC (voice channel - can connect but can't speak)
        await interaction.guild.channels.create({
            name: "tournament-vc",
            type: 2, // Voice
            parent: tournamentCategory.id,
            permissionOverwrites: [
                {
                    id: interaction.guild.id,
                    deny: [PermissionsBitField.Flags.Connect]
                },
                ...registeredRoles.map(role => ({
                    id: role.id,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.Connect],
                    deny: [PermissionsBitField.Flags.Speak]
                }))
            ]
        });

        // Create ID & Pass (text channel - can't send messages, only view)
        await interaction.guild.channels.create({
            name: "id-pass",
            type: 0, // Text
            parent: tournamentCategory.id,
            permissionOverwrites: [
                {
                    id: interaction.guild.id,
                    deny: [PermissionsBitField.Flags.ViewChannel]
                },
                ...registeredRoles.map(role => ({
                    id: role.id,
                    allow: [PermissionsBitField.Flags.ViewChannel],
                    deny: [PermissionsBitField.Flags.SendMessages]
                }))
            ]
        });

        interaction.reply("🚀 Tournament has **started**! Tournament channels created successfully!");
    }
});

// 🟢 Handle Modal Submission
client.on("interactionCreate", async (interaction) => {
    if (!interaction.isModalSubmit()) return;
    if (interaction.customId === "regModal") {
        const guild = getGuildData(interaction.guild.id);
        const teamName = interaction.fields.getTextInputValue("teamName");
        const ign = interaction.fields.getTextInputValue("ign");

        // Check if team name is already taken (case insensitive) in this guild
        const teamNameLower = teamName.toLowerCase();
        const existingTeam = Array.from(guild.registeredTeamNames).find(name => name.toLowerCase() === teamNameLower);
        if (existingTeam) {
            return interaction.reply({ content: "❌ Team name is already taken! Please choose a different name.", ephemeral: true });
        }

        let teammates = [];
        let teammateInfo = "";

        // Handle different tournament modes
        if (guild.tournamentMode === "solo") {
            teammateInfo = "Solo Player";
        } else if (guild.tournamentMode === "duo") {
            const teammateId = interaction.fields.getTextInputValue("teammate");
            try {
                const teammateUser = await interaction.guild.members.fetch(teammateId);
                
                if (!teammateUser) {
                    return interaction.reply({ content: "❌ Teammate not found! Please check the user ID.", ephemeral: true });
                }

                if (guild.registeredUsers.has(teammateUser.id)) {
                    return interaction.reply({ content: "❌ Your teammate is already registered in another team!", ephemeral: true });
                }

                teammates.push(teammateUser);
                teammateInfo = `${teammateUser.user.username} (${teammateId})`;
            } catch (e) {
                return interaction.reply({ content: "❌ Error finding teammate. Please check the user ID.", ephemeral: true });
            }
        } else if (guild.tournamentMode === "squad") {
            const teammatesIds = interaction.fields.getTextInputValue("teammates");
            const idList = teammatesIds.split(",").map(id => id.trim());
            
            if (idList.length !== 3) {
                return interaction.reply({ content: "❌ You must provide exactly 3 teammate user IDs for squad mode!", ephemeral: true });
            }

            let teammateNames = [];
            for (const id of idList) {
                try {
                    const teammateUser = await interaction.guild.members.fetch(id);
                    
                    if (!teammateUser) {
                        return interaction.reply({ content: `❌ Teammate with ID ${id} not found! Please check all user IDs.`, ephemeral: true });
                    }

                    if (guild.registeredUsers.has(teammateUser.id)) {
                        return interaction.reply({ content: `❌ Teammate ${teammateUser.user.username} (${id}) is already registered in another team!`, ephemeral: true });
                    }

                    teammates.push(teammateUser);
                    teammateNames.push(`${teammateUser.user.username} (${id})`);
                } catch (e) {
                    return interaction.reply({ content: `❌ Error finding teammate with ID ${id}. Please check the user ID.`, ephemeral: true });
                }
            }
            teammateInfo = teammateNames.join(", ");
        }

        // Create Role
        let role = await interaction.guild.roles.create({
            name: teamName,
            color: "Random",
            reason: "Tournament Registration"
        });

        // Give role to user
        await interaction.member.roles.add(role);

        // Add teammates to role and register them
        for (const teammate of teammates) {
            await teammate.roles.add(role);
            guild.registeredUsers.add(teammate.id);
            guild.userTeamMap.set(teammate.id, teamName);
        }

        // Register the main user
        guild.registeredUsers.add(interaction.user.id);
        guild.registeredTeamNames.add(teamName); // Store original case, not lowercase
        guild.userTeamMap.set(interaction.user.id, teamName);

        // Create Category
        let category = await interaction.guild.channels.create({
            name: teamName,
            type: 4, // Category
        });

        // Create Text Channel
        await interaction.guild.channels.create({
            name: `${teamName}-text`,
            type: 0, // Text
            parent: category.id,
            permissionOverwrites: [
                {
                    id: interaction.guild.id,
                    deny: [PermissionsBitField.Flags.ViewChannel]
                },
                {
                    id: role.id,
                    allow: [PermissionsBitField.Flags.ViewChannel]
                }
            ]
        });

        // Create Voice Channel
        await interaction.guild.channels.create({
            name: `${teamName}-voice`,
            type: 2, // Voice
            parent: category.id,
            permissionOverwrites: [
                {
                    id: interaction.guild.id,
                    deny: [PermissionsBitField.Flags.Connect]
                },
                {
                    id: role.id,
                    allow: [PermissionsBitField.Flags.Connect]
                }
            ]
        });

        interaction.reply({
            content: `✅ Team **${teamName}** registered!\nMode: ${guild.tournamentMode.toUpperCase()}\nIGN: ${ign}\nTeammates: ${teammateInfo}`,
            ephemeral: true
        });
    }
});

client.login(process.env.TOKEN);

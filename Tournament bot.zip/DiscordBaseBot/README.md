# Discord Bot

A simple Discord bot built with Node.js and Discord.js featuring basic command handling and server interaction.

## Features

- 🤖 Basic command handling system
- 🏓 Ping command with latency display
- 📋 Help command showing all available commands
- 🔧 Configurable command prefix
- 📊 Server statistics and logging
- ⚡ Error handling and graceful shutdown
- 🛡️ Secure token handling with environment variables

## Prerequisites

- Node.js v16.9.0 or higher
- A Discord account
- A Discord application/bot token

## Setup Instructions

### 1. Discord Developer Portal Setup

1. Go to the [Discord Developer Portal](https://discord.com/developers/applications)
2. Click "New Application" and give it a name
3. Go to the "Bot" section in the left sidebar
4. Click "Add Bot"
5. Copy the bot token (keep this secret!)
6. Under "Privileged Gateway Intents", enable:
   - Message Content Intent

### 2. Bot Permissions

When inviting your bot to a server, make sure it has these permissions:
- Send Messages
- Read Message History
- Use Slash Commands
- Embed Links

### 3. Installation

1. Clone or download this project
2. Install dependencies:
   ```bash
   npm install discord.js dotenv
   ```

3. Create a `.env` file in the root directory:
   ```bash
   cp .env.example .env
   